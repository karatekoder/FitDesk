package com.example.fitdesk;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
/*
* Wasn't sure where to add this, but app icon is from a website that gave a free use license
* https://icon-library.net/icon/stretch-icon-21.html
*/

import androidx.appcompat.app.AppCompatActivity;

public class WelcomeActivity extends AppCompatActivity implements View.OnClickListener {

    private FitDeskDB db;
    private Button btnSchedule;
    private Button btnLog;
    private Button btnAddToSchedule;
    Button btnGetStarted;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome_activity);

        btnSchedule = findViewById(R.id.btnSchedule);
        btnSchedule.setOnClickListener(this);
        btnLog = findViewById(R.id.btnLog);
        btnLog.setOnClickListener(this);
        btnAddToSchedule = findViewById(R.id.btnAddToSchedule);
        btnAddToSchedule.setOnClickListener(this);
        btnGetStarted = findViewById(R.id.btnGetStarted);
        btnGetStarted.setOnClickListener(this);

        db = new FitDeskDB(this);
    }

    @Override
    public void onClick(View v){
        if (v.getId() == R.id.btnSchedule) {
            startActivity(new Intent(this, ScheduleActivity.class));
        }
        if (v.getId() == R.id.btnLog){
            startActivity(new Intent(this, LogActivity.class));
        }
        if (v.getId() == R.id.btnAddToSchedule){
            startActivity(new Intent(this, AddActivity.class));
        }
        if (v.getId() == R.id.btnGetStarted){
            startActivity(new Intent(this, ExerciseMenuActivity.class));
        }


    }
}
