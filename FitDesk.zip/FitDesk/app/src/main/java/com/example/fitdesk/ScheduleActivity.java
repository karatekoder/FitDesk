package com.example.fitdesk;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

import androidx.appcompat.app.AppCompatActivity;

public class ScheduleActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    private ListView scheduleListView;
    private FitDeskDB db;
    //Button btnAddToSchedule;


    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.schedule);

        db = new FitDeskDB(this);
        scheduleListView = findViewById(R.id.scheduleListView);
        scheduleListView.setOnItemClickListener(this);

//        btnAddToSchedule = findViewById(R.id.btnAddToSchedule);
//        btnAddToSchedule.setOnClickListener(this);

        updateScheduleDisplay();
    }

//    @Override
//    public void onClick(View v){
//        if (v.getId() == R.id.btnAddToSchedule){
//            startActivity(new Intent(this, AddActivity.class));
//        }
//    }

    @Override
    public void onItemClick(AdapterView<?> parent, View v, int position, long id){
        Intent intent = new Intent(this, EditReminderActivity.class);
        String time;
        String hour;
        String minute;
        HashMap<String, String> reminder = (HashMap<String, String>) scheduleListView.getItemAtPosition(position);
        time = reminder.get("time");
        hour = time.substring(0, 2);
        minute = time.substring(3, 5);


        intent.setAction(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra("hour", hour);
        intent.putExtra("minute", minute);
        //Toast.makeText(this, "Time is: " + hour + ":" + minute, Toast.LENGTH_LONG).show();
        startActivity(intent);
        finish();
    }


    private void updateScheduleDisplay(){
        ArrayList<HashMap<String, String>> data = db.getSchedule();

        int resource = R.layout.schedule_item;
        String[] from = {"time", "activity"};
        int[] to = {R.id.txtTime, R.id.txtActivity};

        SimpleAdapter adapter =
                new SimpleAdapter(this, data, resource, from, to);
        scheduleListView.setAdapter(adapter);
    }

    @Override
    public void onResume(){
        super.onResume();
        updateScheduleDisplay();
    }

}
