package com.example.fitdesk;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;

/*
*much of this code was modified from code found from
*  https://www.loopwiki.com/application/embed-youtube-video-in-android-app/
*/


public class VideoActivity extends YouTubeBaseActivity {

    Button btnRegisterActivity;
    Button btnPlay;
    EditText count;
    FitDeskDB db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.video_activity);
        btnRegisterActivity = findViewById(R.id.btnRegisterActivity);
        btnPlay = findViewById(R.id.btnPlay);
        count = findViewById(R.id.editTextCount);

        db = new FitDeskDB(this);

        final Intent videoIntent = getIntent();

        final YouTubePlayerView youtubePlayerView = findViewById(R.id.youtubePlayerView);
        btnPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String vidID = videoIntent.getStringExtra("vidID");
                //String videoId = editTextId.getText().toString();
                playVideo(vidID, youtubePlayerView);
            }
        });

        btnRegisterActivity.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String sCount =  count.getText().toString().trim();
                if (!sCount.equals("")){
                    Integer iCount = Integer.parseInt(sCount);
                    if (iCount > 0) {
                        try {
                            db.logActivity(videoIntent.getStringExtra("activity"), iCount);
                            startActivity(new Intent(getApplicationContext(), LogActivity.class));
                            finish();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        Toast.makeText(getApplicationContext(), "Good job!", Toast.LENGTH_LONG).show();
                    } else{
                        Toast.makeText(getApplicationContext(), "Count has to be more than 0", Toast.LENGTH_LONG).show();
                    }
                } else{
                    Toast.makeText(getApplicationContext(), "Count cannot be left blank", Toast.LENGTH_LONG).show();

                }


            }
        });


    }

    public void playVideo(final String videoId, YouTubePlayerView youTubePlayerView) {
        //initialize youtube player view
        youTubePlayerView.initialize("AIzaSyDLbwKKHR2SgSnEliZAuZXMj9uM_yhxlnQ",
                new YouTubePlayer.OnInitializedListener() {
                    @Override
                    public void onInitializationSuccess(YouTubePlayer.Provider provider,
                                                        YouTubePlayer youTubePlayer, boolean b) {
                        youTubePlayer.cueVideo(videoId);
                    }

                    @Override
                    public void onInitializationFailure(YouTubePlayer.Provider provider,
                                                        YouTubeInitializationResult youTubeInitializationResult) {

                    }
                });
    }
}
