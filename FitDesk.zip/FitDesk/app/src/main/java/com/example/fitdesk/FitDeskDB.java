package com.example.fitdesk;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

/* Created by Michael Kariuki on Nov 29, 2019
* With help from PlayerDB made by Hildred
 */
public class FitDeskDB {
    //constants
    public static final String DB_NAME = "person.fitdesk";
    public static final int DB_VERSION = 1;
    public Object rawQuery;

    private static class DBHelper extends SQLiteOpenHelper{

        public DBHelper(Context context, String name,
                        SQLiteDatabase.CursorFactory factory, int version){
            super(context, name, factory, version);
        }

        @Override
        public void onCreate(SQLiteDatabase db){
           //make tables
            db.execSQL("CREATE TABLE person (name VARCHAR PRIMARY KEY," +
                    "hoursAtDesk INTEGER )");

//            ContentValues personValues = new ContentValues();
//            personValues.put("name", "YourNameHere");
//            personValues.put("hoursAtDesk", 0);
//            db.insert("person", null, personValues);

            db.execSQL("CREATE TABLE activites (activityID INTEGER PRIMARY KEY  AUTOINCREMENT  NOT NULL , " +
                    "activity VARCHAR NOT NULL, " +
                    "videoID VARCHAR NOT NULL)");

            //region populating activities table
            ContentValues breathingValues = new ContentValues();
            breathingValues.put("activity", "Breathing");
            breathingValues.put("videoID", "sJ04nsiz_M0");
            db.insert("activities", null, breathingValues);

            ContentValues pushupValues = new ContentValues();
            pushupValues.put("activity", "Push-Ups");
            pushupValues.put("videoID", "IODxDxX7oi4");
            db.insert("activities", null, pushupValues);

            ContentValues stretchValues = new ContentValues();
            stretchValues.put("activity", "Stretches");
            stretchValues.put("videoID", "5M-b1c2spPE");
            db.insert("activities", null, stretchValues);
            //endregion

//            db.execSQL("INSERT INTO 'activities' (activityID, activity, videoID)" +
//                    "VALUES  ('breathing', 'sJ04nsiz_M0'), " +
//                    "('pushups', 'IODxDxX7oi4'), " +
//                    "('stretches', '5M-b1c2spPE');");


            db.execSQL("CREATE TABLE activityLog (logID INTEGER PRIMARY KEY  AUTOINCREMENT  NOT NULL , " +
                    "activityID VARCHAR NOT NULL , " +
                    "activity VARCHAR NOT NULL , " +
                    "count INTEGER DEFAULT 1, "+
                    "timeCompleted TEXT NOT NULL, " +
                    "FOREIGN KEY (activityID) REFERENCES activities(activityID))");

            db.execSQL("CREATE TABLE schedule (scheduleID INTEGER PRIMARY KEY  AUTOINCREMENT  NOT NULL , " +
                    "activityID INTEGER NOT NULL , " +
                    "activity VARCHAR NOT NULL , " +
                    "time TEXT NOT NULL, " +
                    "FOREIGN KEY (activityID) REFERENCES activities(activityID))");


        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
            db.execSQL("DROP TABLE \"person\"");
            db.execSQL("DROP TABLE \"activities\"");
            db.execSQL("DROP TABLE \"activityLog\"");
            db.execSQL("DROP TABLE \"schedule\"");
            Log.d("Task List", "Upgrading db from version " + oldVersion + "to " + newVersion);

            onCreate(db);
        }
    }

    private SQLiteDatabase db;
    private DBHelper dbHelper;

    public FitDeskDB(Context context){
        dbHelper = new DBHelper(context, DB_NAME, null, DB_VERSION);
        openWriteableDB();
        closeDB();
    }
    private void openReadableDB() {
        db = dbHelper.getReadableDatabase();
    }

    private void openWriteableDB() {
        db = dbHelper.getWritableDatabase();
    }

    private void closeDB() {
        if (db != null)
            db.close();
    }

    //db will only hold 1 person
    //get name and hours in string separated by space, will parse inside of activity
    ArrayList<HashMap<String, String>> getPlayer(){
        openReadableDB();
        ArrayList<HashMap<String, String>> data =
                new ArrayList<HashMap<String, String>>();
        Cursor cursor = db.rawQuery("SELECT name, hoursAtDesk FROM person",null );
        while (cursor.moveToNext()) {
            HashMap<String, String> map = new HashMap<String, String>();
            map.put("name", cursor.getString(0));
            map.put("hoursAtDesk", cursor.getString(1));
            data.add(map);
        }
        if (cursor != null)
            cursor.close();
        closeDB();

        return data;
    }



    ArrayList<HashMap<String, String>> getSchedule(){
        ArrayList<HashMap<String, String>> data =
                new ArrayList<HashMap<String, String>>();
        openReadableDB();
        Cursor cursor = db.rawQuery("SELECT activity, time FROM schedule ORDER BY time",null );
        while (cursor.moveToNext()) {
            HashMap<String, String> map = new HashMap<String, String>();
            map.put("activity", cursor.getString(0));
            map.put("time", cursor.getString(1));
            data.add(map);
        }
        if (cursor != null)
            cursor.close();
        closeDB();

        return data;
    }

    ArrayList<HashMap<String, String>> getActivityLog(){
        ArrayList<HashMap<String, String>> data =
                new ArrayList<HashMap<String, String>>();
        openReadableDB();
        Cursor cursor = db.rawQuery("SELECT activity, count, timeCompleted FROM activityLog",null );
        while (cursor.moveToNext()) {
            HashMap<String, String> map = new HashMap<String, String>();
            map.put("activity", cursor.getString(0));
            map.put("count", cursor.getString(1));
            map.put("timeCompleted", cursor.getString(2));
            data.add(map);
        }
        if (cursor != null)
            cursor.close();
        closeDB();

        return data;
    }

    void updatePerson(String xName, int newHours) throws Exception{
        openReadableDB();
        openWriteableDB();
        ContentValues content = new ContentValues();
        //String sql = "UPDATE" + " person " + " SET " +"name " + "= " + xName + " AND " + "hoursAtDesk = " + newHours;
        //db.rawQuery(sql, null);
        content.put("name", xName);
        content.put("hoursAtDesk", newHours);
        long nResult = db.update("person", content, null, null);
        if(nResult==-1) throw new Exception("error updating person");

//        String from[] = {"name", "hoursAtDesk"};
//        String where = "name = ?";
//        String[] whereArgs = new String[]{xName};
//        Cursor cursor = db.query("person", from, where, whereArgs, null, null, null, null);
//
//        while(cursor.moveToNext()){
//            content.put("name", xName);
//            content.put("hoursAtDesk", newHours);
//            db.update("person", content, where, whereArgs);
//        }
//        cursor.close();
        closeDB();
    }

    void addActivity(String activity, String time) {
        openWriteableDB();
        ContentValues content = new ContentValues();
        Integer actID = 0;
        if (activity.equals("Breathing")) {
            actID = 1;
        }
        else if(activity.equals("Push-Ups")){
            actID = 2;
        }
        else if(activity.equals("Stretches")){
            actID = 3;
        }

//        if (!time.startsWith("1") || !time.startsWith("2"){
//            time = "0" + time;
//        }
//
//        if ((time.substring(3, time.length())).length() == 1){
//            time = time.substring(0,1) +
//        }
        content.put("activityID", actID);
        content.put("activity", activity);
        content.put("time", time);

        db.insert("schedule", null, content);
        db.close();
    }

    void deleteReminder(String time){
        openReadableDB();
        openWriteableDB();
        try{
            db.delete("schedule", "time = ?", new String[]{time});
        } catch (Exception e){
            e.printStackTrace();
        }
        closeDB();
    }

    void updateReminder(String time) throws Exception{
        openReadableDB();
        openWriteableDB();
        ContentValues content = new ContentValues();
        content.put("time", time);
        String from[] = {"time"};
        String where = "time = ?";
        String[] whereArgs = new String[]{time};
        Cursor cursor = db.query("schedule", from, where, whereArgs, null, null, null, null);

        long nResult = db.update("schedule", content, where, whereArgs);
        if (nResult == -1) throw new Exception("error when updating");
    }

    void logActivity(String activity, Integer count) throws Exception{
        openWriteableDB();
        Integer actID = 0;
        if (activity.equals("Breathing")){
            actID = 1;
        } else if (activity.equals("Push-Ups")){
            actID = 2;
        } else if (activity.equals("Stretches")){
            actID = 3;
        }
        String currentTime = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
        ContentValues content = new ContentValues();
        content.put("activityID", actID);
        content.put("activity", activity);
        content.put("count", count);
        content.put("timeCompleted", currentTime);
        long nResult = db.insert("activityLog", null, content);
        if (nResult == -1) throw new Exception("error when inserting activity to log");
    }

}
