package com.example.fitdesk;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class ExerciseMenuActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnBreathing;
    Button btnPushUps;
    Button btnStretches;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.exercise_menu);

        btnBreathing = findViewById(R.id.btnGoToBreathing);
        btnBreathing.setOnClickListener(this);
        btnPushUps = findViewById(R.id.btnGoToPushUps);
        btnPushUps.setOnClickListener(this);
        btnStretches = findViewById(R.id.btnGoToStretches);
        btnStretches.setOnClickListener(this);
    }

    @Override
    public void onClick(View v){
        Intent videoIntent = new Intent(this, VideoActivity.class);
        videoIntent.setAction(Intent.ACTION_SEND);
        videoIntent.setType("text/plain");
        if (v.getId() == R.id.btnGoToBreathing){
            videoIntent.putExtra("vidID", "sJ04nsiz_M0");
            videoIntent.putExtra("activity", "Breathing");
            startActivity(videoIntent);
        }
        if (v.getId() == R.id.btnGoToPushUps){
            videoIntent.putExtra("vidID", "IODxDxX7oi4" );
            videoIntent.putExtra("activity", "Push-Ups");
            startActivity(videoIntent);
        }
        if (v.getId() == R.id.btnGoToStretches){
            videoIntent.putExtra("vidID", "5M-b1c2spPE" );
            videoIntent.putExtra("activity", "Stretches");
            startActivity(videoIntent);
        }
    }


}
