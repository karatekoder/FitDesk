package com.example.fitdesk;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TimePicker;

import androidx.appcompat.app.AppCompatActivity;

public class EditReminderActivity extends AppCompatActivity implements View.OnClickListener {

    TimePicker editTP;
    Button btnUpdate;
    Button btnDelete;
    Button btnCancel;

    FitDeskDB db;


    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_reminder_activity);

        editTP = findViewById(R.id.editTimePicker);
        editTP.setIs24HourView(true);

        btnCancel = findViewById(R.id.btnCancelReminderEdit);
        btnCancel.setOnClickListener(this);
        btnDelete = findViewById(R.id.btnDeleteReminder);
        btnDelete.setOnClickListener(this);
        btnUpdate = findViewById(R.id.btnUpdateReminder);
        btnUpdate.setOnClickListener(this);

        db = new FitDeskDB(this);

        setClock();

    }

    @Override
    public void onClick(View v){
        if (v.getId() == R.id.btnCancelReminderEdit){
            startActivity(new Intent(this, ScheduleActivity.class));
            finish();
        }
        if (v.getId() == R.id.btnUpdateReminder){
            Intent intent = getIntent();
            String hour = intent.getStringExtra("hour");
            String minute = intent.getStringExtra("minute");
            String time = hour + ":" + minute;
            try {
                db.updateReminder(time);
                startActivity(new Intent(this, ScheduleActivity.class));
                finish();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
        if (v.getId() == R.id.btnDeleteReminder){
            Intent intent = getIntent();
            String hour = intent.getStringExtra("hour");
            String minute = intent.getStringExtra("minute");
            String time = hour + ":" + minute;
            db.deleteReminder(time);
            finish();
            startActivity(new Intent(this, ScheduleActivity.class));

        }
        if (v.getId() == R.id.btnCancelReminderEdit){
            //startActivity(new Intent(this, ScheduleActivity.class));
            finish();
        }
    }

    public void setClock(){
        String hour;
        String minute;
        Intent clockIntent = getIntent();
        hour = clockIntent.getStringExtra("hour");
        minute = clockIntent.getStringExtra("minute");

        editTP.setHour(Integer.parseInt(hour));
        editTP.setMinute(Integer.parseInt(minute));
    }


}

