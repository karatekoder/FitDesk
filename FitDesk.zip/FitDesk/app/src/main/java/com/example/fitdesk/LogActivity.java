package com.example.fitdesk;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;

import androidx.appcompat.app.AppCompatActivity;

public class LogActivity extends AppCompatActivity {

    FitDeskDB db;
    ListView logListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.log);

        db = new FitDeskDB(this);
        logListView = findViewById(R.id.logListView);

        updateLogDisplay();
    }

    private void updateLogDisplay(){
        ArrayList<HashMap<String, String>> data = db.getActivityLog();

        int resource = R.layout.log_item;
        String[] from = {"timeCompleted", "activity", "count"};
        int[] to = {R.id.txtTimeCompleted, R.id.txtLogActivity, R.id.txtCount};

        SimpleAdapter adapter =
                new SimpleAdapter(this, data, resource, from, to);
        logListView.setAdapter(adapter);
    }

    @Override
    public void onResume(){
        super.onResume();
        updateLogDisplay();
    }
}
