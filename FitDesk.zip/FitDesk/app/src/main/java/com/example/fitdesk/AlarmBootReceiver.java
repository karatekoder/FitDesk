package com.example.fitdesk;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * code from https://github.com/ptyagicodecamp/RepeatingLocalNotifications
 */

public class AlarmBootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals("android.intent.action.BOOT_COMPLETED")) {
            //only enabling one type of notifications for demo purposes
            String x = "12";
            String y = "00";
            NotificationHelper.scheduleRepeatingElapsedNotification(context);
        }
    }
}

