package com.example.fitdesk;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class EditProfileActivity extends AppCompatActivity implements View.OnClickListener {

    FitDeskDB db;

    Button btnSave;

    EditText editName;
    EditText editHours;

    String newName;
    String sNewHours;
    Integer newHours;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_profile);

        btnSave = (Button) findViewById(R.id.btnSaveProfile);
        btnSave.setOnClickListener(this);

        editName = findViewById(R.id.editName);
        editHours = findViewById(R.id.editHours);
        db = new FitDeskDB(this);

    }

    @Override
    public void onClick(View v){
        if(v.getId() == R.id.btnSaveProfile){
            try {
                newName = editName.getText().toString();
                newHours = Integer.parseInt(editHours.getText().toString());

                    db.updatePerson(newName, newHours);

                startActivity(new Intent(this, ProfileActivity.class));
                finish();
                }
            catch (Exception e){
                e.printStackTrace();
            }
        }
    }
}
