package com.example.fitdesk;

import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

import androidx.appcompat.app.AppCompatActivity;

import static android.app.AlarmManager.RTC_WAKEUP;

public class AddActivity extends AppCompatActivity implements View.OnClickListener {

    FitDeskDB db;
    Button btnAddBreathing;
    Button btnAddPushUps;
    Button btnAddStretches;
    TimePicker timePicker;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_activity);

        btnAddBreathing = findViewById(R.id.btnAddBreathing);
        btnAddBreathing.setOnClickListener(this);
        btnAddPushUps = findViewById(R.id.btnAddPushUps);
        btnAddPushUps.setOnClickListener(this);
        btnAddStretches = findViewById(R.id.btnAddStretches);
        btnAddStretches.setOnClickListener(this);

        timePicker = findViewById(R.id.timePicker1);
        timePicker.setIs24HourView(true);

        db = new FitDeskDB(this);
    }

    @Override
    public void onClick(View v){
        String hour;
        String minute;

        String time;

        hour = timePicker.getCurrentHour().toString();
        minute = timePicker.getCurrentMinute().toString();

        if (timePicker.getCurrentHour() < 12){
            hour = "0" + hour;
        }
        if (timePicker.getCurrentMinute() < 10){
            minute = "0" + minute;
        }

        time = hour + ":" + minute;

        switch (v.getId()){
            case R.id.btnAddBreathing:
                db.addActivity("Breathing", time);
                Toast.makeText(this, "Reminder to do Breathing Exercises added for " + time, Toast.LENGTH_LONG).show();
                NotificationHelper.scheduleRepeatingRTCNotification(getApplicationContext(), hour, minute);
                NotificationHelper.enableBootReceiver(getApplicationContext());
                startActivity(new Intent(this, ScheduleActivity.class));
                finish();
                break;
            case R.id.btnAddPushUps:
                db.addActivity("Push-Ups", time);
                Toast.makeText(this, "Reminder to do Push-Ups added for " + time, Toast.LENGTH_LONG).show();
                NotificationHelper.scheduleRepeatingRTCNotification(getApplicationContext(), hour, minute);
                NotificationHelper.enableBootReceiver(getApplicationContext());
                startActivity(new Intent(this, ScheduleActivity.class));
                finish();
                break;
            case R.id.btnAddStretches:
                db.addActivity("Stretches", time);
                Toast.makeText(this, "Reminder to do Stretches added for " + time, Toast.LENGTH_LONG).show();
                NotificationHelper.scheduleRepeatingRTCNotification(getApplicationContext(), hour, minute);
                NotificationHelper.enableBootReceiver(getApplicationContext());
                startActivity(new Intent(this, ScheduleActivity.class));
                finish();
                break;
            default:
                //
        }
    }

    public void addAlarm(int hour, int minute){
        //Intent alarmIntent = new Intent(getApplicationContext(), NotificationReceiver.class);
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        calendar.set(Calendar.HOUR_OF_DAY, hour, minute);

        Intent intent = new Intent(getApplicationContext(), AlarmReceiver.class);
        PendingIntent alarmIntent = PendingIntent.getBroadcast(getApplicationContext(), RTC_WAKEUP, intent, PendingIntent.FLAG_UPDATE_CURRENT);

    }
}
