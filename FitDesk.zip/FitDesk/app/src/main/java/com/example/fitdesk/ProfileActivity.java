package com.example.fitdesk;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.HashMap;

import androidx.appcompat.app.AppCompatActivity;
/*
* Couldn't get this to work so just scrapped it
 */

public class ProfileActivity extends AppCompatActivity implements View.OnClickListener {

    private  Button btnEditProfile;

    private TextView txtName;
    private TextView txtHours;

    private FitDeskDB db;

    ArrayList<HashMap<String, String>> personInfo =
            new ArrayList<HashMap<String, String>>();
    public String name;
    public String sHoursAtDesk;
    public Integer hoursAtDesk;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile);

        btnEditProfile = (Button) findViewById(R.id.btnEditProfile);
        btnEditProfile.setOnClickListener(this);

        txtName = findViewById(R.id.txtName);
        txtHours = findViewById(R.id.txtHours);

        db = new FitDeskDB(this);

        populateFields();
    }

    @Override
    public void onClick(View v){
        if (v.getId() == R.id.btnEditProfile){
            startActivity( new Intent(this, EditProfileActivity.class));
            finish();
        }
    }

    public void populateFields(){
        personInfo = db.getPlayer();
        if (personInfo == null){
            txtName.setText("?");
            txtHours.setText("?");
        }
        else {

            try {
                txtName.setText(personInfo.get(0).toString());
                txtHours.setText(personInfo.get(1).toString());
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "Unable to parse name", Toast.LENGTH_LONG).show();
            }
        }

    }
}
